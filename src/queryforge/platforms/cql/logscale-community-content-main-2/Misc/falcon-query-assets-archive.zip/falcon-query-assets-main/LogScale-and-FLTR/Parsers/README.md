# :bangbang: We've moved! :bangbang:

The new site for LogScale Community Content can be found here:

https://github.com/crowdstrike/logscale-community-content

...

:warning: These are unofficial parsers. :warning:

These are unofficial parsers used by the LogScale SE team during POVs. They are not meant to be a replacement for parsers in the official LogScale [Package Marketplace](https://library.humio.com/humio-server/packages-marketplace.html). However, feel free to use the content as necessary since they are meant to be learning examples. 