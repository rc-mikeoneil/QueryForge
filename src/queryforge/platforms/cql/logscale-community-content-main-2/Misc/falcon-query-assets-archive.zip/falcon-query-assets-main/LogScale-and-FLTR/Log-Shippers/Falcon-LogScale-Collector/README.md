# :bangbang: We've moved! :bangbang:

The new site for LogScale Community Content can be found here:

https://github.com/crowdstrike/logscale-community-content

...

These are configuration examples used by the field engineering team. 

Official documentation for the Falcon LogScale Collector can be found on [the LogScale documentation site](https://library.humio.com/humio-server/log-shippers-log-collector.html).
